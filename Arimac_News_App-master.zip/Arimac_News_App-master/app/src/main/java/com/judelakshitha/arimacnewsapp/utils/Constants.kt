package com.judelakshitha.arimacnewsapp.utils


    val SPLASH_DELAY = 3000
    val BASE_URL = ""
    val RECIPE_ITEM_KEY = "NEWS_ITEM_KEY"

