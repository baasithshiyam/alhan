package com.judelakshitha.arimacnewsapp.ui.base.component.details

import com.judelakshitha.arimacnewsapp.data.DataRepositorySource
import com.judelakshitha.arimacnewsapp.ui.base.BaseViewModel

class NewsDetailsViewModel constructor(private val dataRepository: DataRepositorySource): BaseViewModel() {


}