package com.judelakshitha.arimacnewsapp.data.dto.news

data class News(val newsList:ArrayList<NewsItem>)
