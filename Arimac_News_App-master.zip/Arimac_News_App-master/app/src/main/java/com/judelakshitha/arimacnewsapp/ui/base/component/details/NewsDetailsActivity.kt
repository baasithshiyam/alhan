package com.judelakshitha.arimacnewsapp.ui.base.component.details

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.judelakshitha.arimacnewsapp.R
import com.judelakshitha.arimacnewsapp.ui.base.BaseActivity

class NewsDetailsActivity : BaseActivity() {
    override fun observeViewModel() {
        TODO("Not yet implemented")
    }

    override fun initViewBinding() {
        TODO("Not yet implemented")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news_details)
    }
}