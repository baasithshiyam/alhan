package com.judelakshitha.arimacnewsapp.data.login

data class LoginRequest(val email: String, val password:String)
