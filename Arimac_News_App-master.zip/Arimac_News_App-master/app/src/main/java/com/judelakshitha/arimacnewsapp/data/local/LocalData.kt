package com.judelakshitha.arimacnewsapp.data.local

import android.content.Context

class LocalData constructor(val context:Context) {



}