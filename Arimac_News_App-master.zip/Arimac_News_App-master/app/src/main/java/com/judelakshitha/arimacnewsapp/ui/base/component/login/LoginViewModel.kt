package com.judelakshitha.arimacnewsapp.ui.base.component.login

import com.judelakshitha.arimacnewsapp.data.DataRepository
import com.judelakshitha.arimacnewsapp.ui.base.BaseViewModel

class LoginViewModel constructor(private val dataRepository: DataRepository): BaseViewModel() {


}