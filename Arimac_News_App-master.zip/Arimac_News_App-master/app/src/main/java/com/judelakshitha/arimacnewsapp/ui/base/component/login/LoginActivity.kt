package com.judelakshitha.arimacnewsapp.ui.base.component.login

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.judelakshitha.arimacnewsapp.R
import com.judelakshitha.arimacnewsapp.ui.base.BaseActivity

class LoginActivity : BaseActivity() {
    override fun observeViewModel() {
        TODO("Not yet implemented")
    }

    override fun initViewBinding() {
        TODO("Not yet implemented")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
    }
}